

# React Weather Application 

# first npm run build application
# to start the app, type the command: npm start
#it will run at localhost:3000
# it will show the weather for today and for next 7 days
# search the location name in the search bar, and it will show the weather of this place